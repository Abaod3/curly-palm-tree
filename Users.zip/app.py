from flask import Flask, render_template, request, jsonify, redirect, url_for
import threading
import queue
import time
import json
import os
import requests
import itertools
import string
import random
from pathlib import Path
import traceback
from urllib3.exceptions import MaxRetryError

app = Flask(__name__)

# Global variables
RPS = 0
REQUESTS = 0
WORKS = 0
TAKEN = 0
DEACTIVATE = False
checker_queue = queue.Queue()
checker_threads = []
checker_running = False

# Create necessary directories
os.makedirs("logs", exist_ok=True)
os.makedirs("results", exist_ok=True)
os.makedirs("data", exist_ok=True)

# Create empty files if they don't exist
def create_empty_file(file_path):
    file_path = Path(file_path)
    if not file_path.exists():
        file_path.parent.mkdir(parents=True, exist_ok=True)
        with file_path.open("w", encoding='utf-8'):
            pass

create_empty_file("logs/log.txt")
create_empty_file("results/hits.txt")
create_empty_file("data/names_to_check.txt")
create_empty_file("data/proxies.txt")
create_empty_file("data/config.json")

# Load config
def load_config():
    try:
        with open('data/config.json', 'r') as f:
            return json.load(f)
    except:
        return {}

def save_config(config_data):
    with open('data/config.json', 'w') as f:
        json.dump(config_data, f, indent=4)

# Load proxies
def load_proxies():
    try:
        with open('data/proxies.txt', 'r', encoding='utf-8') as f:
            proxies = f.read().splitlines()
            return [p for p in proxies if p.strip()]
    except:
        return []

# Load names to check
def load_names_to_check():
    try:
        with open('data/names_to_check.txt', 'r', encoding='utf-8') as f:
            names = f.read().splitlines()
            return [n for n in names if n.strip()]
    except:
        return []

# Save names to check
def save_names_to_check(names):
    with open('data/names_to_check.txt', 'w', encoding='utf-8') as f:
        for name in names:
            f.write(f"{name}\n")

# Discord username checker class
class DiscordChecker:
    def __init__(self):
        self.endpoint = "https://discord.com/api/v9"
        self.headers_post = {"Content-Type": "application/json"}
        self.session = requests.Session()
        self.proxies_not_working = []
        self.timeout = 30

    def check_username(self, name, proxy=None):
        global RPS, REQUESTS, WORKS, TAKEN
        
        try:
            if proxy:
                proxy_url = f"http://{proxy.strip()}"
                proxies = {"http": proxy_url, "https": proxy_url}
            else:
                proxies = None

            r = self.session.post(
                url=self.endpoint + "/unique-username/username-attempt-unauthed",
                headers=self.headers_post,
                json={"username": name},
                proxies=proxies,
                timeout=self.timeout
            )
            
            REQUESTS += 1

            if r.status_code in [200, 201, 204]:
                if r.json()["taken"]:
                    TAKEN += 1
                    return {"available": False, "response": r.json(), "status": r.status_code}
                else:
                    WORKS += 1
                    # Save hit to file
                    with open("results/hits.txt", "a", encoding='utf-8') as f:
                        f.write(f"{name}\n")
                    return {"available": True, "response": r.json(), "status": r.status_code}
            
            elif r.status_code == 429:
                return {"available": "RATELIMITED", "response": r.json(), "status": r.status_code}
            else:
                return {"available": "ERROR", "response": r.json(), "status": r.status_code}

        except Exception as e:
            return {"available": "ERROR", "response": str(e), "status": 0}

# Worker function for threading
def worker():
    global checker_running
    checker = DiscordChecker()
    
    while checker_running:
        try:
            if not checker_queue.empty():
                name_data = checker_queue.get(timeout=1)
                name, proxy = name_data
                
                result = checker.check_username(name, proxy)
                
                # Log result
                with open("logs/log.txt", "a", encoding='utf-8') as f:
                    f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} - {name}: {result}\n")
                
                checker_queue.task_done()
            else:
                time.sleep(0.1)
        except:
            time.sleep(0.1)

# RPS calculator
def rps_calculator():
    global RPS
    while checker_running:
        requests_before = REQUESTS
        time.sleep(1)
        RPS = REQUESTS - requests_before

@app.route('/')
def index():
    config = load_config()
    proxies = load_proxies()
    names = load_names_to_check()
    
    return render_template('index.html', 
                         config=config, 
                         proxies=proxies, 
                         names=names,
                         checker_running=checker_running)

@app.route('/start_checker', methods=['POST'])
def start_checker():
    global checker_running, checker_threads
    
    if checker_running:
        return jsonify({"success": False, "message": "Checker is already running"})
    
    data = request.get_json()
    thread_count = int(data.get('threads', 5))
    
    # Load names and proxies
    names = load_names_to_check()
    proxies = load_proxies()
    
    if not names:
        return jsonify({"success": False, "message": "No names to check. Please add names first."})
    
    if not proxies:
        proxies = [None]
    
    # Create proxy cycle
    proxy_cycle = itertools.cycle(proxies)
    
    # Add names to queue
    for name in names:
        proxy = next(proxy_cycle)
        checker_queue.put([name.strip(), proxy])
    
    # Start threads
    checker_running = True
    checker_threads = []
    
    for _ in range(thread_count):
        thread = threading.Thread(target=worker, daemon=True)
        thread.start()
        checker_threads.append(thread)
    
    # Start RPS calculator
    rps_thread = threading.Thread(target=rps_calculator, daemon=True)
    rps_thread.start()
    
    return jsonify({"success": True, "message": f"Started checker with {thread_count} threads"})

@app.route('/stop_checker', methods=['POST'])
def stop_checker():
    global checker_running, checker_threads
    
    if not checker_running:
        return jsonify({"success": False, "message": "Checker is not running"})
    
    checker_running = False
    
    # Wait for threads to finish
    for thread in checker_threads:
        thread.join(timeout=1)
    
    # Clear queue
    while not checker_queue.empty():
        checker_queue.get()
    
    return jsonify({"success": True, "message": "Checker stopped"})

@app.route('/get_stats')
def get_stats():
    return jsonify({
        "rps": RPS,
        "requests": REQUESTS,
        "works": WORKS,
        "taken": TAKEN,
        "running": checker_running
    })

@app.route('/save_config', methods=['POST'])
def save_config_route():
    data = request.get_json()
    save_config(data)
    return jsonify({"success": True, "message": "Configuration saved"})

@app.route('/save_names', methods=['POST'])
def save_names_route():
    data = request.get_json()
    names = data.get('names', [])
    save_names_to_check(names)
    return jsonify({"success": True, "message": f"Saved {len(names)} names"})

@app.route('/save_proxies', methods=['POST'])
def save_proxies_route():
    data = request.get_json()
    proxies = data.get('proxies', [])
    
    with open('data/proxies.txt', 'w', encoding='utf-8') as f:
        for proxy in proxies:
            f.write(f"{proxy}\n")
    
    return jsonify({"success": True, "message": f"Saved {len(proxies)} proxies"})

@app.route('/generate_names', methods=['POST'])
def generate_names():
    data = request.get_json()
    length = int(data.get('length', 3))
    count = int(data.get('count', 1000))
    char_type = data.get('charType', 'all')
    custom_chars = data.get('customChars', '')
    
    # Define character sets based on type
    if char_type == 'letters':
        chars = string.ascii_lowercase
    elif char_type == 'numbers':
        chars = string.digits
    elif char_type == 'letters_numbers':
        chars = string.ascii_lowercase + string.digits
    elif char_type == 'custom':
        chars = custom_chars if custom_chars else string.ascii_lowercase + string.digits + "_"
    else:  # 'all'
        chars = string.ascii_lowercase + string.digits + "_" + "."
    
    # Validate characters
    if not chars:
        return jsonify({"success": False, "message": "No valid characters provided"})
    
    names = []
    used_names = set()
    
    attempts = 0
    max_attempts = count * 10  # Prevent infinite loops
    
    while len(names) < count and attempts < max_attempts:
        name = ''.join(random.choice(chars) for _ in range(length))
        if name not in used_names:
            names.append(name)
            used_names.add(name)
        attempts += 1
    
    # If we couldn't generate enough unique names, use what we have
    if len(names) < count:
        return jsonify({
            "success": True, 
            "message": f"Generated {len(names)} unique names (could not generate {count} with current settings)", 
            "names": names
        })
    
    save_names_to_check(names)
    
    return jsonify({"success": True, "message": f"Generated {len(names)} names", "names": names})

@app.route('/get_hits')
def get_hits():
    try:
        with open('results/hits.txt', 'r', encoding='utf-8') as f:
            hits = f.read().splitlines()
        return jsonify({"success": True, "hits": hits})
    except:
        return jsonify({"success": False, "hits": []})

@app.route('/get_names')
def get_names():
    try:
        names = load_names_to_check()
        return jsonify({"success": True, "names": names})
    except:
        return jsonify({"success": False, "names": []})

@app.route('/get_proxies')
def get_proxies():
    try:
        proxies = load_proxies()
        return jsonify({"success": True, "proxies": proxies})
    except:
        return jsonify({"success": False, "proxies": []})

@app.route('/clear_hits', methods=['POST'])
def clear_hits():
    try:
        # Clear hits file
        with open('results/hits.txt', 'w', encoding='utf-8') as f:
            f.write('')
        
        # Reset global variables
        global WORKS
        WORKS = 0
        
        return jsonify({"success": True, "message": "All hits cleared successfully"})
    except Exception as e:
        return jsonify({"success": False, "message": f"Error clearing hits: {str(e)}"})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
